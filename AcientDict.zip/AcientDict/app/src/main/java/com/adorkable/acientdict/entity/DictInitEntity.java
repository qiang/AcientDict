package com.adorkable.acientdict.entity;

/**
 * Created by liuqiang
 * Date: 2016-05-02
 * Time: 16:39
 * 对应于第一个fragment页面，词典页
 */
public class DictInitEntity extends BaseEntity{



}
