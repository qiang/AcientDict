package com.adorkable.acientdict.mvp.model.impl;

import com.adorkable.acientdict.mvp.model.SearchInteractor;

/**
 * Created by liuqiang on 2016/5/4.
 */
public class SearchInteractorImpl implements SearchInteractor{
    @Override
    public void loadPresearchList() {

    }

    @Override
    public void loadSearchResult() {

    }
}
