package com.adorkable.acientdict.mvp.presenter;

/**
 * Created by liuqiang
 * Date: 2016-04-05
 * Time: 19:03
 */
public interface SplashPresenter {
    void initialized();
}
