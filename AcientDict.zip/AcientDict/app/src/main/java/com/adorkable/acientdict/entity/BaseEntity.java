package com.adorkable.acientdict.entity;

/**
 * Author: liuqiang
 * Date: 2016-07-17
 * Time: 15:56
 * 留给后续的接口
 */
public class BaseEntity {

}
