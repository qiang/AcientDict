package com.adorkable.acientdict.mvp.presenter.impl;

import com.adorkable.acientdict.mvp.presenter.SearchPresenter;

/**
 * Author: liuqiang
 * Date: 2016-05-04
 * Time: 15:05
 * Description:
 */
public class SearchPresenterImpl implements SearchPresenter {
}
