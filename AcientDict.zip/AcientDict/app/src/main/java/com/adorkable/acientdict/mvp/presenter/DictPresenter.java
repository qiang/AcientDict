package com.adorkable.acientdict.mvp.presenter;

/**
 * Created by liuqiang
 * Date: 2016-05-02
 * Time: 20:51
 */
public interface DictPresenter {

    void loadData();
}
