package com.adorkable.acientdict.mvp.view;

/**
 * Created by liuqiang on 2016/5/4.
 */
public interface SearchView extends BaseView {
    void showSearchResult();    //显示某个单词的搜索结果

    void showPreSearchList();    //预搜索
}
