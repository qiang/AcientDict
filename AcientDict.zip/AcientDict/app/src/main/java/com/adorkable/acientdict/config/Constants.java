package com.adorkable.acientdict.config;

/**
 * Created by liuqiang on 15/12/8.
 */
public class Constants {

    /**
     * 微博
     */
    public static final String WEI_BO_APP_KEY = "4137405970";
    public static final String WEI_BO_REDIRECT_URL = "https://api.weibo.com/oauth2/default.html";
    public static final String WEI_BO_SCOPE =
            "email,direct_messages_read,direct_messages_write,"
                    + "friendships_groups_read,friendships_groups_write,statuses_to_me_read,"
                    + "follow_app_official_microblog," + "invitation_write";

    /**
     * WeiXin
     */
    public static final String WEI_XIN_APP_ID = "wx4fcd3eb8c449d2f5";
    public static final String WEI_XIN_SECRET = "c3e6c48c626abbd41bd69cbd010b696f";



}
