package com.adorkable.acientdict.mvp.presenter;

/**
 * Author: liuqiang
 * Date: 2016-05-03
 * Time: 18:20
 * Description:
 */
public interface SearchPresenter {

}
